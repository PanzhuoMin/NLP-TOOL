import nlpcda
from nlpcda import  Simbert
import json

config = {
        'model_path': 'model/chinese_simbert_L-12_H-768_A-12',
        'CUDA_VISIBLE_DEVICES': '0',
        'max_len': 128,
        'seed': 1
}

def simbert_think(sentence):
        simbert = Simbert(config=config)
        sent = sentence
        synonyms = simbert.replace(sent=sent, create_num=1)
        print(synonyms)
        return synonyms

# 加载数据集
with open('raw-source/source2.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 数据增广
augmented_data = []
augmented_data2 = []

for item in data:
    content = item['content']
    summary = item['summary']

    print(content)
    for _ in range(3):
        augmented_content = simbert_think(content)
        augmented_summary = simbert_think(summary)

        augmented_item = {'content': augmented_content, 'summary': augmented_summary}
        augmented_data.append(augmented_item)

# 保存增广后的数据集
with open('augmented_simbert.json', 'w', encoding='utf-8') as f:
    json.dump(augmented_data, f, ensure_ascii=False, indent=4)