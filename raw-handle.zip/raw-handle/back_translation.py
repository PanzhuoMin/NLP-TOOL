import json
from nlpcda import baidu_translate

def back_translation(sentence):

    en_s = baidu_translate(content=sentence, appid='20230717001747505', secretKey='RBmV1rIXxeoDH4tVUS6b', t_from='zh',
                           t_to='en')
    zh_s = baidu_translate(content=en_s, appid='20230717001747505', secretKey='RBmV1rIXxeoDH4tVUS6b', t_from='en',
                           t_to='zh')

    return zh_s

# 加载数据集
with open('raw-source/source2.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 数据增广
augmented_data = []
augmented_data2 = []

for item in data:
    content = item['content']
    summary = item['summary']

    print(content)

    augmented_content = back_translation(content)
    # augmented_summary = back_translation(summary)


    augmented_item = {'content': augmented_content, 'summary': summary}
    augmented_data.append(augmented_item)

# 保存增广后的数据集
with open('output/augmentate_btrans.json', 'w', encoding='utf-8') as f:
    json.dump(augmented_data, f, ensure_ascii=False, indent=4)
