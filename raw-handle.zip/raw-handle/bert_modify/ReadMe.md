# download
- bert-base chinese: https://github.com/google-research/bert
- roberta_zh: https://github.com/brightmart/roberta_zh
- albert_zh: https://github.com/brightmart/albert_zh
- xlnet_zh: https://github.com/brightmart/xlnet_zh

来自于：[https://github.com/google-research/bert](https://github.com/google-research/bert)
