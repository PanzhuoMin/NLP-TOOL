import json
import random
import nltk
import jieba
nltk.download('omw-1.4')
nltk.download('wordnet')
from nltk.corpus import wordnet



def get_synonyms(word):
    synonyms = []
    for syn in wordnet.synsets(word, lang='cmn'):
        for lemma in syn.lemmas('cmn'):
            synonyms.append(lemma.name())
    return synonyms

def synonym_replacement(sentence, n):                         #同义词替换
    words = list(jieba.cut(sentence))
    new_words = words.copy()

    for _ in range(n):
        random_index = random.randint(0, len(words) - 1)
        random_word = words[random_index]
        synonyms = get_synonyms(random_word)

        if len(synonyms) > 0:
            replacement = random.choice(synonyms)
            new_words[random_index] = replacement

    new_sentence = ''.join(new_words)
    return new_sentence




def random_deletion(sentence, p=0.3):       #随机删除
    words = list(jieba.cut(sentence))

    remaining_words = []
    for word in words:
        if random.uniform(0, 1) > p:
            remaining_words.append(word)

    new_sentence = ''.join(remaining_words)
    return new_sentence



# 加载数据集
with open('raw-source/source2.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 数据增广
augmented_data = []
augmented_data2 = []

for item in data:
    content = item['content']
    summary = item['summary']

    print(content)

    augmented_content = synonym_replacement(content, n=random.randint(3, 5))  # 随机选择1到3次替换
    augmented_summary = synonym_replacement(summary, n=random.randint(3, 5))

    # augmented_content = random_deletion(augmented_content, p=0.2)  # 进行随机删除
    # augmented_summary = random_deletion(augmented_summary, p=0.2)

    augmented_item = {'content': augmented_content, 'summary': augmented_summary}
    augmented_data.append(augmented_item)

# 保存增广后的数据集
with open('output/augmented_normal.json', 'w', encoding='utf-8') as f:
    json.dump(augmented_data, f, ensure_ascii=False, indent=4)
