
import json

def get_prompt_list(keyword):
    return [f'{keyword}',
            f'你知道{keyword}吗?',
            f'{keyword}是什么？',
            f'介绍一下{keyword}',
            f'你听过{keyword}吗?',
            f'啥是{keyword}？',
           ]


# 加载数据集
with open('output.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 数据增广
augmented_data = []
augmented_data2 = []

for item in data:
    content = item['content']
    summary = item['summary']

    print(content)



    augmented_item = [{'content': x, 'summary': summary}for x in get_prompt_list(content)]
    # augmented_data.append(augmented_item)
    extend = augmented_data.extend(augmented_item)

# 保存增广后的数据集
with open('output.json', 'w', encoding='utf-8') as f:
    json.dump(augmented_data, f, ensure_ascii=False, indent=4)
