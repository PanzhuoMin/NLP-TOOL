import json

# 读取JSON数据
with open('raw-source/source2.json', 'r', encoding='utf-8') as file:
    json_data = json.load(file)

# 转换为txt文档
with open('output/outputtxt.txt', 'w', encoding='utf-8') as file:
    for index, item in enumerate(json_data):
        content = item['content']
        summary = item['summary']
        file.write(f"{content}")
        # 最后一条数据后面不添加空行
        if index != len(json_data) - 1:
            file.write("\n")
        file.write(f"{summary}\n")

