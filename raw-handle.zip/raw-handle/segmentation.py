import json
import random

# 读取train.json数据集
with open('source2.json', 'r', encoding='utf-8') as file:
    data = json.load(file)

# 随机打乱数据集
random.shuffle(data)

# 计算训练集和验证集的分割点
split_point = int(0.7 * len(data))

# 划分训练集和验证集
train_data = data[:split_point]
valid_data = data[split_point:]

# 保存训练集和验证集到对应文件
with open('train_data.json', 'w', encoding='utf-8') as file:
    json.dump(train_data, file, ensure_ascii=False, indent=4)

with open('valid_data.json', 'w', encoding='utf-8') as file:
    json.dump(valid_data, file, ensure_ascii=False, indent=4)
