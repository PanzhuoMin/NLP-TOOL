import json

# 读取txt文档
with open('output/outputtxt.txt', 'r', encoding='utf-8') as file:
    txt_data = file.read()

# 解析txt文档并生成json数据
json_data = []
lines = txt_data.split('\n')
for i in range(0, len(lines), 2):
    content = lines[i]
    summary = lines[i+1]
    item = {"content": content, "summary": summary}
    json_data.append(item)

# 将json数据写入文件
with open('output/outputjson.json', 'w', encoding='utf-8') as file:
    json.dump(json_data, file, ensure_ascii=False, indent=4)