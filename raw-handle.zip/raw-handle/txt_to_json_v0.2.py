import os

default_path = os.getcwd()

def txt_json_transform(file_path=default_path, output_path=default_path):
    whole_str = ''
    with open('raw-source/source.txt', 'r', encoding='utf-8') as txt_file:
        txt_data = txt_file.readlines()
        the_first = True
        for line in txt_data:
            # Split the line based on the separator used in the .txt file
            row = line.strip()
            if the_first == True:
                whole_str = whole_str + row
                the_first = False
            else:
                whole_str = whole_str + '\n' + ',' + row
    whole_str = '[' + whole_str + ']'
    with open(output_path + '\\output.json', 'w', encoding = 'utf-8') as json_file:
        json_file.write(whole_str)

txt_json_transform()